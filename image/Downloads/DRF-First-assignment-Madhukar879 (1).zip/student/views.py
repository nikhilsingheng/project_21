from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from rest_framework.response import Response
from student import models
from student.serializers import StudentSerializer


@csrf_exempt
@api_view(['GET', 'POST'])
def student_list_create(request):
    if request.method == 'GET':
        student_data = models.Student.objects.all()
        response = StudentSerializer(student_data, many=True)
        return Response(response.data, status=200)

    if request.method == 'POST':
      qs = models.Student.objects.filter(student_regNo=request.data['student_regNo'])
      if qs:
        return Response({"student_regNo":["student with this student regNo already exists."]}, status=400)
      else:

        req_data = request.data
        student_data = StudentSerializer(data=req_data)
        if student_data.is_valid():
            student_data.save()
            r_data = models.Student.objects.filter(student_regNo=request.data['student_regNo'])
            s_data= StudentSerializer(r_data, many=True)
            return Response(s_data.data[0], status=201)
        else:
          return Response(data=student_data.errors)


@csrf_exempt
@api_view(['GET', 'PUT', 'DELETE'])
def student_update_delete(request, id):
    if request.method == 'GET':
        student_data = models.Student.objects.filter(id=id)
        response = StudentSerializer(student_data, many=True)
        return Response(response.data[0], status=200)
   
    if request.method == 'PUT':
     
        try:
            request_data = request.data
            student_obj = models.Student.objects.get(id=id)
            student_obj_updated = StudentSerializer(student_obj, data=request_data)
            if student_obj_updated.is_valid():
                student_obj_updated.save()
                return Response(student_obj_updated.data, status=200)
            return Response(status=400, data=student_obj_updated.errors)
        except models.Student.DoesNotExist:
            return Response(status=404, data={'msg': 'no such student data  found'})


    if request.method == 'DELETE':
        student_data = models.Student.objects.get(id=id)
        student_data.delete()
        return Response(data={'status': 'deleted'}, status=204)




