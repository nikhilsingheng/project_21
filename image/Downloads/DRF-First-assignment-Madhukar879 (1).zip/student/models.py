from django.db import models

# Create your models here.

class Student(models.Model):
    student_regNo = models.TextField(primary_key=False, unique=True)
    student_name = models.TextField()
    student_email = models.TextField()
    student_mobile = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.student_name
