from django.urls import path
from . import views

urlpatterns = [
   
   path('', views.student_list_create, name="student_list_create"),
   path('', views.student_update_delete, name="student_update_delete"),
   path('<int:id>', views.student_update_delete, name="student_update_delete"),
 
]
