import datetime
from django.http import JsonResponse
from animals import models
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def getorpostmammal(request,*args,**kwargs):
  if request.method=='GET':
    if 'mammals' in kwargs:
      mammals=models.Mammal.objects.get(name=kwargs['mammals'])
      return JsonResponse({
        'name':mammals.name,
        'species':mammals.species,
        'food':mammals.food,
        'gender':mammals.gender,
      
      })
    else:
      mammals=models.Mammals.object.filter().values_List
      ('name','species','gender','food')
      response=mammals
      return JsonResponse({'data':List(response)})

  elif request.method=='POST':
    mammals=request.POST
    modles.Mammal.objects.create(
      name=mammals['name'],
      species=mammals['species'],
      food=mammals['food'],
      gender=mammals['gender'],
    
    )
    return JsonResponse({'created':{'name':mammals['name']}})

  elif request.method=='PUT':
    if 'mammals' in kwargs:
      mammals=models.objects.get(name=kwargs['mammals'])
      mammals.last_feed_time=datetime.datetime.now()
      mammals.save()
      return JsonResponse(
        {
          'feeded':str(kwargs['mammals'])
        }
      )
    
  elif request.method=='DELETE':
   if 'mammals' in kwargs:
     mammals=models.Mammal.objects.get(name=kwargs['mammals'])
     mammals.delete()
     return JsonResponse (
      {
        'Deleted':str(kwargs['mammals'])
      }
    )

@csrf_exempt
def getpostbird(request,args,*kwargs):
    if request.method=="GET":
        if 'birds' in kwargs:
            birds=models.Bird.object.get(name=kwargs['birds']
            )
            return JsonResponse({
                'name':birds.name,
                'species':birds.species,
                'food':birds.food
            }

            )
        else:
          birds=models.Bird.object.filter().values_list
          ("name","spacies","food")
          response=birds
          return JsonResponse({"data":list(response)})

    elif request.method=='POST':
            bird=request.POST
            models.Bird.object.create(
                name=bird['spacies'],
                food=birds['food'],
            )
            return JsonResponse({"created":{"name":bird['name']}}
               
    elif request.method=="PUT":
            if 'birds' in kwargs:
                birds=models.Bird.object.get(name=kwargs['birds'])
                birds.last_feed_time=datetime.datetime.now()
                birds.save()
                       
                return JsonResponse(
                           {
                               "Feeded":str(kwargs['birds'])
                           }
                       )
                       
             elif request.method="DELETE":
                 if 'birds'in kwargs:
                     birds=model.Bird.object.get(name=kwargs['birds'])
                     birds.delete(
                         return JsonResponse(
                             {
                                 "Deleted":str(kwargs['birds'])
                             }
                         )
    @csrf_exempt
def getpostfish(request,args,*kwargs):
    if request.method=="GET":
        if 'fishes' in kwargs:
            fishes=models.Fish.object.get(name=kwargs['fishes']
            )
            return JsonResponse({
                'color':fishes.color,
                'species':fishes.species,
                'food':fishes.food,
                'count':fishes.count
            }

            )
        else:
          fishes=models.Fish.object.filter().values_list
          ("name","spacies","food","count")
          response=fishes
          return JsonResponse({"data":list(response)})             

    elif request.method=='POST':
            fishes=request.POST
            models.Fish.object.create(
                color=fishes['color'],
                species=fishes['species'],
                food=fishes['food'],
                count=fishes['count']
            )
            return JsonResponse({"created":{"name":fishes['name']}}        
        
    elif request.method=="PUT":
            if 'fishes' in kwargs:
                fishes=models.fish.object.get(name=kwargs['fishes'])
                fishes.last_feed_time=datetime.datetime.now()
                fishes.save()
                       
                return JsonResponse(
                           {
                               "Feeded":str(kwargs['fishes'])
                           }
                       )       
         elif request.method=="DELETE":
                 if 'fishes'in kwargs:
                     fishes=model.Fish.object.get(name=kwargs['fishes'])
                     fishes.delete(
                         return JsonResponse(
                             {
                                 "Deleted":str(kwargs['fishes'])
                             }
                         

  
