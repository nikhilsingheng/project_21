from django.http import JsonResponse
from animals import models
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def Mammal(request):
    if request.method=="GET":
        q=models.Mammal.objects.all()
        qlist=[]
        for x in q:
            qitem=[x.name,x.species,x.gender,x.food]
            qlist.append(qitem)
        return JsonResponse({"data":qlist})
    elif request.method=="POST":
        r=request.POST
        models.Mammal.objects.create(name=r['name'],species=r['species'],gender=r["gender"],food=r["food"])
        return JsonResponse({"created":{"name":"tiger"}})

@csrf_exempt
def Bird(request):
    if request.method == "GET":
        q = models.Bird.objects.all()
        qlist = []
        for x in q:
            qitem = [x.name,x.species,x.food]
            qlist.append(qitem)
        return JsonResponse({"data": qlist})
    elif request.method == "POST":
        r=request.POST
        models.Bird.objects.create(name=r['name'],species=r['species'],food=r["food"])
        return JsonResponse({"created":{"name":"crow"}})

@csrf_exempt
def Fish(request):
    if request.method=="GET":
        q = models.Fish.objects.all()
        qlist = []
        for x in q:
            qitem = [x.color,x.species,x.food,x.count]
            qlist.append(qitem)
        return JsonResponse({"data": qlist})
    elif request.method=="POST":
        r=request.POST
        models.Fish.objects.create(color=r['color'],species=r['species'],food=r["food"],count=r['count'])
        return JsonResponse({"created":{"species":"Tuna"}})