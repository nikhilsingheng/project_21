from django.urls import path
from . import views

urlpatterns = [
  path('mammals/',views.Mammal,name="mammals"),
  path('birds/',views.Bird,name="birds"),
  path('fishes/',views.Fish,name="fishes")
]